"use client";
import { createBrowserClient } from "@supabase/ssr";

/** Cliente de navegador (solo panel admin: subida de imágenes, sesión). */
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
  );
}
